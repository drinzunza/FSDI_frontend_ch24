import "./footer.css";

const Footer = () => {
  return (
    <div className="footer">
      <h4>Organika Store 2021. All rights reserved</h4>
      <h5>Sergio Inzunza</h5>
    </div>
  );
}

export default Footer;
