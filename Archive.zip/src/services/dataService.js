
var catalog = [
    {
        _id: "1o2lkasf12ohasd908",
        title: "Carrots",
        price: 12.57,
        stock: 12,
        image: "carrot1.jpeg",
        category: "Vegetable"
    },
    {
        _id: "y123iuyohiqs",
        title: "Strawberry",
        price: 32.34,
        stock:99,
        image: "strawberry.jpeg",
        category: "Fruit"
    }
];


class DataService {

    getCatalog() {
        // do the magic to connect to server
        // and retrieve the catalog

        // return mock data
        return catalog;
    }
}

export default DataService;